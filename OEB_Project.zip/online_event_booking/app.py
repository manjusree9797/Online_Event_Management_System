from flask import Flask, render_template, request, redirect, session
import sqlite3
import random

app = Flask(__name__)
app.secret_key = "secret123"

# -----------------------------
# Initialize Database
# -----------------------------
def init_db():
    conn = sqlite3.connect('event.db')
    c = conn.cursor()

    # Users table
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    ''')

    # Events table
    c.execute('''
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            venue TEXT,
            date TEXT,
            seats INTEGER,
            booked INTEGER DEFAULT 0
        )
    ''')

    # Bookings table
    c.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            event_id INTEGER,
            ticket_id TEXT
        )
    ''')

    # Default admin
    c.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES ('admin','admin','admin')")
    conn.commit()
    conn.close()

init_db()

# -----------------------------
# Registration
# -----------------------------
@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        username = request.form.get("username")
        password = request.form.get("password")
        role = request.form.get("role")
        if not role:
            return "Please select a role!"
        conn = sqlite3.connect('event.db')
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username,password,role) VALUES (?,?,?)", (username,password,role))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return "Username already exists!"
        conn.close()
        return redirect("/login")
    return render_template("register.html")

# -----------------------------
# Login
# -----------------------------
@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        username = request.form.get("username")
        password = request.form.get("password")
        conn = sqlite3.connect('event.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username,password))
        user = c.fetchone()
        conn.close()
        if user:
            session["user_id"] = user[0]
            session["role"] = user[3]
            session["username"] = user[1]
            if user[3]=="admin":
                return redirect("/admin")
            else:
                return redirect("/dashboard")
        else:
            return "Invalid credentials. Make sure you registered first and selected a role."
    return render_template("login.html")

# -----------------------------
# Logout
# -----------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# -----------------------------
# Dashboard
# -----------------------------
@app.route("/dashboard", methods=["GET","POST"])
def dashboard():
    if "user_id" not in session:
        return redirect("/login")

    conn = sqlite3.connect('event.db')
    c = conn.cursor()

    # Organizer adds event
    if session["role"]=="organizer" and request.method=="POST":
        name = request.form.get("name")
        venue = request.form.get("venue")
        date = request.form.get("date")
        seats = int(request.form.get("seats"))
        c.execute("INSERT INTO events (name,venue,date,seats) VALUES (?,?,?,?)", (name,venue,date,seats))
        conn.commit()

    # Fetch events
    if session["role"]=="user":
        c.execute("SELECT * FROM events WHERE booked < seats")
        events = c.fetchall()
        user_type = "user"
    else:
        c.execute("SELECT * FROM events")
        events = c.fetchall()
        user_type = "organizer"

    conn.close()
    return render_template("dashboard.html", events=events, username=session["username"], user_type=user_type)

# -----------------------------
# Book Event
# -----------------------------
@app.route("/book/<int:event_id>")
def book(event_id):
    if "user_id" not in session or session["role"]!="user":
        return redirect("/login")

    ticket_id = str(random.randint(1000,9999))
    user_id = session["user_id"]

    conn = sqlite3.connect('event.db')
    c = conn.cursor()
    c.execute("INSERT INTO bookings (user_id,event_id,ticket_id) VALUES (?,?,?)", (user_id,event_id,ticket_id))
    c.execute("UPDATE events SET booked = booked+1 WHERE id=?", (event_id,))
    conn.commit()
    conn.close()

    return f"<h2>✅ Booking Successful! Ticket ID: {ticket_id}</h2><a href='/dashboard'>Back</a>"

# -----------------------------
# Admin Panel
# -----------------------------
@app.route("/admin")
def admin():
    if "user_id" not in session or session["role"]!="admin":
        return redirect("/login")

    conn = sqlite3.connect('event.db')
    c = conn.cursor()
    c.execute("SELECT * FROM events")
    events = c.fetchall()
    c.execute("SELECT * FROM bookings")
    bookings = c.fetchall()
    conn.close()
    return render_template("admin.html", events=events, bookings=bookings)

# -----------------------------
# Run App
# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)
